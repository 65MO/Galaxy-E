# shiny-GIE-test
Based on the work of https://github.com/65MO/Galaxy-E/tree/master/GIE/shiny-GIE-master

